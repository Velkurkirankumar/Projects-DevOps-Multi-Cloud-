# Import the array module for creating and managing arrays
# - `array` is used here to efficiently store and manipulate the color data for the LEDs.
# - This module is lightweight and provides better performance compared to lists
#   when working with large amounts of numeric data, such as the color values for LEDs.
import array

# Import the Pin class for GPIO control from the machine module
# - The `Pin` class allows us to control specific pins on the microcontroller (RP2040).
# - It is part of the MicroPython `machine` module, which provides access to hardware-specific functionality.
# - Here, it will be used to define and manage the GPIO pin connected to the NeoPixel ring.
from machine import Pin

# Import the rp2 module for working with PIO (Programmable I/O) on RP2040
# - The `rp2` module provides support for the Programmable I/O (PIO) system on the RP2040.
# - PIO is a powerful feature that allows for precise timing control and protocol generation, like the WS2812 signal.
import rp2

# Define the GPIO pin connected to the NeoPixel data line
# - `NEOPIXEL_PIN` specifies which GPIO pin is used for controlling the NeoPixel ring.
# - This is where the PIO program will output the data signal to control the LEDs.
NEOPIXEL_PIN = 0

# Define the number of LEDs in the NeoPixel ring
# - `NUM_LEDS` is the total number of individual LEDs in the NeoPixel ring.
# - This is important to correctly configure the data structure and address each LED.
NUM_LEDS = 16

# Configure a PIO program for controlling WS2812 (NeoPixel) LEDs
# - This PIO assembly program generates the precise timing signal required by WS2812 LEDs.
# - WS2812 LEDs require a specific timing protocol to set the color of each LED.
@rp2.asm_pio(
    sideset_init=rp2.PIO.OUT_LOW,  # Configure the side-set pin (data line) to start LOW
    autopull=True,  # Automatically fetch new data from the FIFO when needed
    pull_thresh=24  # Pull 24 bits at a time (8 bits each for red, green, blue)
)
def ws2812():
    wrap_target()  # Define the start of the PIO program loop
    label("bitloop")  # Label for looping through each bit of the data
    out(x, 1)               .side(0) [2]  # Output one bit of data, keeping the line LOW for 2 cycles
    jmp(not_x, "do_zero")   .side(1) [1]  # If the bit is 0, jump to the "do_zero" label
    jmp("bitloop")          .side(1) [3]  # If the bit is 1, continue the loop, keeping the line HIGH for 3 cycles
    label("do_zero")  # Label for handling a 0 bit
    nop()                   .side(0) [3]  # Do nothing but keep the line LOW for 3 cycles
    wrap()  # Define the end of the PIO program loop

# Create a state machine instance to run the ws2812 PIO program
# - The state machine handles the execution of the PIO program and outputs the signal to the NeoPixel ring.
sm = rp2.StateMachine(
    0,             # Index of the state machine (RP2040 has multiple state machines)
    ws2812,        # PIO program to run
    freq=8000000,  # Set the frequency for data output to 8 MHz
    sideset_base=Pin(NEOPIXEL_PIN)  # GPIO pin to be used for the side-set signal
)

# Start the state machine so it begins executing the ws2812 program
sm.active(1)

# Function to update the NeoPixel LEDs with new data
def update_neopixel(led_data):
    # Convert the input list into an array of 32-bit unsigned integers
    # - The `array` module is used to create a buffer that holds the RGB color data for the LEDs.
    # - Each element represents the color of one LED in the GRB (Green, Red, Blue) format.
    array_data = array.array("I", led_data)
    
    # Send the array data to the state machine for processing
    # - `sm.put()` sends the array data to the PIO program for output.
    # - The `8` specifies the FIFO buffer depth to manage data transfer.
    sm.put(array_data, 8)

# Function to handle user input and control the NeoPixel LEDs
def control_led_by_command():
    # Initialize an array to represent the LED colors, starting with all LEDs off
    # - Each LED is initially set to black/off (0x000000).
    led_data = [0] * NUM_LEDS

    # Enter an infinite loop to continuously process user commands
    while True:
        try:
            # Prompt the user for a command (LED index and color) or exit signal
            command = input("Enter LED number and color (e.g., '0 FFA500') or 'exit' to quit: ").strip()

            # If the user enters "exit", exit the program
            if command.lower() == "exit":
                print("Exiting...")
                break

            # Split the command into parts (LED number and hexadecimal color)
            parts = command.split()
            if len(parts) == 2:
                # Extract and validate the LED number
                led_number = int(parts[0])
                hex_color = parts[1]

                # Ensure the LED number is within the valid range
                if 0 <= led_number < NUM_LEDS:
                    # Validate the hexadecimal color format
                    if len(hex_color) == 6 and all(c in "0123456789ABCDEFabcdef" for c in hex_color):
                        # Convert the hexadecimal color to RGB values
                        # - Extract and convert the red, green, and blue components from the hexadecimal input.
                        red = int(hex_color[0:2], 16)
                        green = int(hex_color[2:4], 16)
                        blue = int(hex_color[4:6], 16)

                        # Reset all LEDs and set the specified LED to the given color
                        # - Construct a 32-bit integer for the color in GRB format.
                        led_data = [0] * NUM_LEDS
                        led_data[led_number] = (green << 16) | (red << 8) | blue

                        # Update the NeoPixel ring with the new data
                        update_neopixel(led_data)
                    else:
                        print("Invalid hexadecimal color. Please enter a valid 6-character hexadecimal color.")
                else:
                    print(f"Invalid LED number. Please enter a number between 0 and {NUM_LEDS - 1}.")
            else:
                print("Invalid input format. Use 'LED_number HEX_color', e.g., '0 FFA500'.")
        
        # Handle invalid inputs, such as non-integer LED numbers
        except ValueError:
            print("Invalid input. Please ensure the LED number is an integer and the color is a valid hexadecimal.")

# Start the command-based control for NeoPixel LEDs
# - This function continuously accepts user input to set colors for specific LEDs or exit the program.
control_led_by_command()

