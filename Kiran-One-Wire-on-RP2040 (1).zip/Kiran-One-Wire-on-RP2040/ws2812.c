 /**
 * WS2812b LED 16-Ring (ONE WIRE USING RP2040)
*/


// #include <stdio.h>                   // Include the standard input/output library for printing to the console
// #include "pico/stdlib.h"              // Include Raspberry Pi Pico standard library for basic functions like GPIO access
// #include "hardware/pio.h"             // Include library for controlling Raspberry Pi Pico's Programmable I/O (PIO)
// #include "ws2812.pio.h"               // Include a custom PIO program for controlling WS2812 LED strips

// // Define constants for the LED configuration
// #define IS_RGBW false                // Define if the LEDs are RGBW (false means RGB, true would mean RGBW)
// #define WS2812_PIN 0                 // GPIO pin number to which the WS2812 LED strip is connected
// #define NUM_PIXELS 16                // The total number of LEDs in the strip (16 LEDs)
// #define WHITE_COLOR 0xFFFFFF         // RGB value for white color (0xFFFFFF represents full intensity for Red, Green, and Blue)
// #define GREEN_COLOR 0x00FF00         // RGB value for green color (full intensity green, no red or blue)
// #define RED_COLOR 0xFF0000           // RGB value for red color (full intensity red, no green or blue)
// #define BLUE_COLOR 0x0000FF          // RGB value for blue color (full intensity blue, no red or green)
// #define OFF_COLOR 0x000000           // RGB value for LED off (no color, all components turned off)

// // Function to send a pixel's color data to the LED strip
// static inline void put_pixel(PIO pio, uint sm, uint32_t pixel_grb) {
//     // Shift the color value by 8 bits (to match the PIO program's requirements) and send it to the state machine
//     pio_sm_put_blocking(pio, sm, pixel_grb << 8u);
// }

// // Function to set the color of a specific LED by its index
// void set_led_at_index(PIO pio, uint sm, int index, uint32_t color) {
//     // Loop through all pixels in the strip
//     for (int i = 0; i < NUM_PIXELS; i++) {
//         if (i == index) {
//             put_pixel(pio, sm, color); // If it's the target index, set the color of the LED
//         } else {
//             put_pixel(pio, sm, OFF_COLOR); // For all other LEDs, turn them off
//         }
//     }
// }

// // Main function to control the LEDs in a loop
// int main() {
//     stdio_init_all();                // Initialize standard I/O functions (needed to use printf)
    
//     // Initialize PIO (Programmable Input/Output) to handle communication with the WS2812 LEDs
//     PIO pio = pio0;                  // Use PIO0 for controlling the LEDs (can choose other PIOs if needed)
//     uint sm = 0;                     // Set the state machine number (0 in this case)
//     uint offset = pio_add_program(pio, &ws2812_program); // Load the custom PIO program for WS2812
//     ws2812_program_init(pio, sm, offset, WS2812_PIN, 800000, IS_RGBW); // Initialize the PIO program with pin, speed, and RGBW setting

//     // Main loop: Cycle through the LEDs, alternating colors
//     while (1) {
//         // Set the color of the first LED (index 0) to white and then turn it off
//         set_led_at_index(pio, sm, 0, WHITE_COLOR); // Turn on the first LED with white color
//         sleep_ms(2000);                           // Wait for 2 seconds
//         set_led_at_index(pio, sm, 0, OFF_COLOR);  // Turn off the first LED
//         sleep_ms(2000);                           // Wait for 2 seconds

//         // Set the color of the second LED (index 1) to green and then turn it off
//         set_led_at_index(pio, sm, 1, GREEN_COLOR); // Turn on the second LED with green color
//         sleep_ms(2000);                           // Wait for 2 seconds
//         set_led_at_index(pio, sm, 1, OFF_COLOR);  // Turn off the second LED
//         sleep_ms(2000);                           // Wait for 2 seconds

//         // Set the color of the third LED (index 2) to red and then turn it off
//         set_led_at_index(pio, sm, 2, RED_COLOR);   // Turn on the third LED with red color
//         sleep_ms(2000);                           // Wait for 2 seconds
//         set_led_at_index(pio, sm, 2, OFF_COLOR);  // Turn off the third LED
//         sleep_ms(2000);                           // Wait for 2 seconds
        
//         // Set the color of the fourth LED (index 3) to blue and then turn it off
//         set_led_at_index(pio, sm, 3, BLUE_COLOR);  // Turn on the fourth LED with blue color
//         sleep_ms(2000);                           // Wait for 2 seconds
//         set_led_at_index(pio, sm, 3, OFF_COLOR);  // Turn off the fourth LED
//         sleep_ms(2000);                           // Wait for 2 seconds

//         // Repeat the pattern indefinitely
//     }

//     return 0; // The program will never reach here because of the infinite loop in the main function
// }












#include <pico/time.h>           // Include Pico library for time-related functions
#include <stdbool.h>             // Include standard library for boolean types
#include <stdio.h>               // Include standard library for input/output functions
#include "pico/stdlib.h"         // Include Pico standard library for basic IO functions
#include "hardware/pio.h"        // Include library for Programmable IO (PIO) control
#include "ws2812.pio.h"          // Include generated PIO program header for WS2812 control
#include "ws2812.h"              // Include WS2812 library for LED control functions

// Constants for LED control
#define IS_RGBW false                // Define whether the LEDs are RGBW (false = RGB only)
#define NEOPIXEL_PIN 0               // GPIO pin number connected to the WS2812 LED strip
#define NUM_LEDS 16                  // Total number of LEDs in the NeoPixel ring
#define OFF_COLOR 0x000000           // Define the RGB value for "off" (no color)

// Function to send a single pixel's color data to the LED strip
static inline void put_pixel(PIO pio, uint sm, uint32_t pixel_grb) {
    // Send the 24-bit GRB color value to the PIO state machine    stdio_init_all();                  // Initialize standard IO for UART communication

    pio_sm_put_blocking(pio, sm, pixel_grb << 8u); 
}

// Function to set all LEDs to the same color
void set_all_leds(PIO pio, uint sm, uint32_t color) {
    for (int i = 0; i < NUM_LEDS; i++) { // Loop through each LED
        put_pixel(pio, sm, color);      // Set the color for the current LED
    }
}

// Function to set the color of a specific LED based on its index
void set_led_at_index(PIO pio, uint sm, int index, uint32_t color) {
    // Loop through all LEDs in the ring
    for (int i = 0; i < NUM_LEDS; i++) {
        if (i == index) {
            put_pixel(pio, sm, color);      // Set the specified LED to the target color
        } else {
            put_pixel(pio, sm, OFF_COLOR); // Turn off all other LEDs
        }
    }
}

// Function to convert a hexadecimal string to an integer
uint32_t hex_to_int(const char *str) {
    uint32_t result = 0; // Initialize the result to 0
    while (*str) {       // Loop through each character in the string
        char c = *str;   // Get the current character
        int value = 0;

        if (c >= '0' && c <= '9') {
            value = c - '0';              // Convert '0'-'9' to numerical value
        } else if (c >= 'A' && c <= 'F') {
            value = c - 'A' + 10;         // Convert 'A'-'F' to numerical value
        } else if (c >= 'a' && c <= 'f') {
            value = c - 'a' + 10;         // Convert 'a'-'f' to numerical value
        } else {
            break; // Stop processing if an invalid character is encountered
        }

        result = (result << 4) | value; // Shift the result and add the new value
        str++; // Move to the next character
    }
    return result; // Return the converted integer
}

// Function to process a command received via serial input
const char *process_command(const char *cmd, PIO pio, uint sm) {
    int led_index = -1;                   // Variable to store the LED index
    char color_str[7] = {0};             // Buffer for hex color string (6 chars + null terminator)

    if (sscanf(cmd, "%d %6s", &led_index, color_str) == 2) { // Parse the command into index and color
        uint32_t color = hex_to_int(color_str);             // Convert the hex color string to an integer

        if (led_index >= 0 && led_index < NUM_LEDS) { // Validate the LED index
            set_led_at_index(pio, sm, led_index, color); // Set the LED at the specified index
            return "LED updated successfully!\r\n";    // Return success message
        } else {
            return "Invalid LED index. Index must be between 0 and 15.\r\n"; // Return error for invalid index
        }
    }
    return "Invalid command format. Use: <index> <hex_color>\r\n"; // Return error for invalid format
}

// Callback function to handle serial input
void read_serial_data(void *param) {
    PIO pio = ((PIO *)param)[0];      // Extract the PIO instance from the callback parameter
    uint sm = ((uint *)param)[1];    // Extract the state machine number

    char cmd_buffer[64] = {0};       // Buffer to store the received command
    size_t index = 0;                // Current index in the command buffer

    while (index < sizeof(cmd_buffer) - 1) { // Loop until the buffer is full or a command is complete
        char c = getchar_timeout_us(0); // Read a character from serial input (non-blocking)
        if (c == PICO_ERROR_TIMEOUT) { // Check if no character is available
            continue;                  // Skip to the next iteration if no character is received
        }

        if (c == '\n' || c == '\r') {  // Check for end of command
            break;                     // Exit the loop when the command terminator is found
        }

        cmd_buffer[index++] = c;      // Add the character to the buffer
    }

    cmd_buffer[index] = '\0';         // Null-terminate the command string

    const char *response = process_command(cmd_buffer, pio, sm); // Process the received command
    printf("%s", response);                                     // Print the response to serial output
}

// Main function
int main() {
    stdio_init_all();                  // Initialize standard IO for UART communication
    sleep_ms(5000);                    // Optional delay to allow setup time

    PIO pio = pio0;                    // Select PIO instance (PIO0)
    uint sm = 0;                       // Use state machine 0
    uint offset = pio_add_program(pio, &ws2812_program); // Load the WS2812 program into PIO memory
    ws2812_program_init(pio, sm, offset, NEOPIXEL_PIN, 800000, IS_RGBW); // Initialize WS2812 program

    set_all_leds(pio, sm, OFF_COLOR);  // Turn off all LEDs initially

    void *callback_param[] = {pio, (void *)(uintptr_t)sm}; // Parameters for the callback function
    stdio_set_chars_available_callback(read_serial_data, callback_param); // Register the callback

    while (true) {                     // Main loop
        tight_loop_contents();         // Keep the processor busy while waiting for callbacks
    }

    return 0; // Return from main (though this line is never reached)
}

