#ifndef ws2812_H
#define ws2812_H

#define AT_CMD "AT"

 #define AT_INPUT "AT+INPUT"
 #define AT_RESP "+INPUT"

const char *input_command();
const char *Process_at_command(const char *cmd);

#endif