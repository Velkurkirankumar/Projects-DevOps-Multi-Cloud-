## **Introduction**

### pico [micro controller](https://www.raspberrypi.com/products/raspberry-pi-pico/)
- Raspberry Pi Pico is a low-cost, high-performance microcontroller board with flexible digital interfaces. Key features include:

- RP2040 microcontroller chip designed by Raspberry Pi in the United Kingdom

- Dual-core Arm Cortex M0+ processor, flexible clock running up to 133 MHz

- 264KB of SRAM, and 2MB of on-board flash memory

- USB 1.1 with device and host support

- Low-power sleep and dormant modes

- Drag-and-drop programming using mass storage over USB

- 26 × multi-function GPIO pins

- 2 × SPI, 2 × I2C, 2 × UART, 3 × 12-bit ADC, 16 × controllable PWM channels

- Accurate clock and timer on-chip

- Temperature sensor

- Accelerated floating-point libraries on-chip

- 8 × Programmable I/O (PIO) state machines for custom peripheral support

![image](https://github.com/user-attachments/assets/ef953982-2cbf-4d0b-b202-2f6357e56537)


### [WS2812 Neopixel](https://protocentral.com/product/neopixel-ring-16-x-ws2812-5050-rgb-led-with-integrated-drivers/?srsltid=AfmBOooKt8WryE6osCBRqb5mc4wvf6_42q-G9VfMkWUWwBi5Y6yll6UG)

- This Neo pixel ring can be easily programmed to follow a particular pattern or to change the colour pattern.

- Round and round and round they go! 16 ultra bright smart LED NeoPixels are arranged in a circle with 1.75″ (44.5mm) outer diameter.
- The rings are ‘chainable’ – connect the output pin of one to the input pin of another.
- Use only one microcontroller pin to control as many as you can chain together! Each LED is addressable as the driver chip is inside the LED.
- Each one has ~18mA constant current drive so the color will be very consistent even if the voltage varies, and no external choke resistors are required making the design slim.
- Power the whole thing with 5VDC (4-7V works) and you’re ready to rock.
- There is a single data line with a very timing-specific protocol.
- Since the protocol is very sensitive to timing, it requires a real-time microconroller such as an AVR, Arduino, PIC, mbed, etc.
- It cannot be used with a Linux-based microcomputer or interpreted microcontroller such as the netduino or Basic Stamp.
- As it requires hand-tuned assembly it is only for AVR cores but others may have ported this chip driver code so please google around.
- An 8MHz or faster processor is required.
- Comes as a single ring with 16 individually addressable RGB LEDs assembled and tested.

**Technical details**
**Dimensions:**

- Outer diameter: 44.5mm / 1.8″;
- Inner diameter: 31.7mm / 1.2″
- Thickness: 6.7mm / 0.3″
- As of 7/16/204 we are now shipping with a standard-thickness PCB and we added an extra ground and power breakout
- Weight: 3.03g

![image](https://github.com/user-attachments/assets/320f8b47-92f0-4911-8905-fee9adafe2b5)


### MicroPython

What is **MicroPython**?

- **MicroPython** is a full implementation of the Python 3 programming language that runs directly on **embedded hardware** like Raspberry Pi Pico.
- Get an **interactive prompt** (the REPL) to execute commands immediately via **USB** Serial, and a built-in filesystem.
- The Pico port of **MicroPython** includes modules for accessing **low-level chip-specific hardware**.


**Requirements needed:**
1. **[USB](https://www.amazon.in/amazon-basics-Braided-Charging-Transfer/dp/B0CH1499X7?th=1)** cable with Micro B.
2. **[pico](https://www.raspberrypi.com/products/raspberry-pi-pico/)**  microcontroller.
3. **[Jumper wires](https://www.amazon.in/ApTechDeals-Jumper-Female-breadboard-jumper/dp/B074J9CPV3)** both **male** and **female** wires.
4. **[Breadboard](https://www.amazon.in/REES52-Solderless-Breadboard-Points-MB102/dp/B01IN2TSAO/ref=sr_1_26?crid=3VC3QH3Z7KDM0&dib=eyJ2IjoiMSJ9.rdOR5BdLeU-uZdHR0kWRZEbVNF6bxJxpWvRlmssQhhV7LweWLgJ2-C7rqk39Co8otEsNQI3zrELAzTz_r0hCNn4gRxKd4yz0gmRVLCV3nM0EkBi_YN_lk25yFh0_Fgq5qUJS9uXUJoogu1Pn3Xz_cn9gUjjVCG0BUaZH_CFxxBtAbAEH-9QKAIrBZN04S6qfm7Sds6m6lofBMU663DZkdvs24UblDJmWXE6sgVyrWWWcgoYSYWY-01tItoZq8lkRbIX8bqC-HvH1bBUP7Q3Gr2qEB9EHfScTzFkolYed_bxKE1l1PxUzBhbTF0WTEfeC5xWNpo1Djdiz8GFdjW5BHMUik7T5KY47R3asV_8EBlo.2zsQxgdq-GR2iQrfehhXqkARhmjvU5zutIrttQPqjgk&dib_tag=se&keywords=breadboard&qid=1733913374&s=industrial&sprefix=breadboard%2Cindustrial%2C206&sr=1-26)**.
5. **[ws2812 neopixel](https://protocentral.com/product/neopixel-ring-16-x-ws2812-5050-rgb-led-with-integrated-drivers/?srsltid=AfmBOooKt8WryE6osCBRqb5mc4wvf6_42q-G9VfMkWUWwBi5Y6yll6UG)** round ring.
6. **power supply**.

**Connections**
- There are 3pins in the **neopixel** led i.e; **DataIn** pin, **5V pin**, **Ground pin** that is connected/sorted through female wires.
- Take **breadboard** and place the **pico** microcontroller on the **breadboard**.
- Connect the male wires to the female wires.
- Now take the DataIn pin and connect to the GPIO "0" i.e; 1 in pico, want any reference link go through this [datasheet](https://datasheets.raspberrypi.com/pico/Pico-R3-A4-Pinout.pdf).
- Now take 5V pin and connect to VBUS that is 40 pin in pico, so here VBUS can handles the 5v.
- And finally the ground pin that is connected to 8th pin in pico, keep anywhere that grd pin is supported/existed, according to the datasheet there are eight grounds.(i.e; 3, 8, 13, 18, 23, 28, 33, 38)

![image](https://github.com/user-attachments/assets/9ddec670-3e08-45b2-aad6-dcdc2ed59c34)


#### Procedure
**Step 1:**
- Install [Thonny](https://thonny.org/), there will three options like windows, mac, linux choose accordingly to device os.

**Step 2:**
- Go to options and select interpreter and select the raspberrypi pico and also select port automatically and click ok

**Step 3:**
- Push and hold the BOOTSEL button while connecting the Pico with a USB cable to a computer.

**Step 4:**
- Release the BOOTSEL button once the Pico appears as a Mass Storage Device called RPI-RP2.

**Step 5:**
- The install page will trigger on the screen, just install and close it.

**Step 6:**
- Now run the [code](https://github.com/slicktronix/Kiran/blob/One-Wire-on-RP2040/onewire.py) in the thonny compiler.
- The o/p displays like this as given below
```
example:>>>
%Run -c $EDITOR_CONTENT
Enter LED number and color (e.g., '0 FFA500') or 'exit' to quit: 0 00ff00
```

- Now enter the index that want to glow the led and also give color index in hexadecimal format to particular color as per the requirement.
- Refer this [link](https://www.color-hex.com/color/ffa500) to the color format in to hexadecimal.
- ex: **"0" it is an index and "00ff00" it is an hexadecimal** So it will glow the led in 0 index as green light.
- Examples like **hexadecimal** format given below;
```
0 00ff00 for green
1 ff0000 for red
2 0000ff for blue
```
**Step 7:**
- Want to **reboot** the **pico** just press **ctrl+D** for the soft reboot of pico.

**Ex:**
```
MPY: soft reboot
MicroPython v1.21.0 on 2023-10-06; Raspberry Pi Pico with RP2040
Type "help()" for more information.
```

